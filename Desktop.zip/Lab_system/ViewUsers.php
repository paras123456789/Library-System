<?php
if (!isset($_SESSION)) {
session_start();
}
if(isset($_SESSION['user'])){
 ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ps Notes</title>

    <!-- Bootstrap core CSS,JS -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
  <link rel="stylesheet" href="./vendor/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="./jquery.dataTables.min.css">
  <script src="./vendor/jquery.min.js"></script>
  <script src="./vendor/bootstrap.min.js"></script>
  <script src="./jquery.dataTables.min.js"></script>

  </head>

  <body>
<!-- menu bar template -->
  <?php include('menu.php'); ?>


    <!-- Page Content -->
<!-- Page Content -->
    <div class="container">
      <br>
      <h2>Manage<span style="color: red;"> Users..</span></h2>
      <hr>
      <div class="row">
        <!-- content goes here -->
        <div class="col-md-3">
          <button class="btn-sm btn-info" data-toggle="modal" data-target="#myuserModal">Add new User</button>
          <img src="user.png" height="250" width="250">
        </div>
        <div class="col-md-9">


          <?php
           if(isset($_SESSION['saveBook'])){ ?>
          <p class="alert alert-success">
          <b><?php echo $_SESSION['saveBook']; unset($_SESSION['saveBook']); ?></b>
          </p>
           <?php } ?>

           <?php
           if(isset($_SESSION['deleteBook'])){ ?>
          <p class="alert alert-danger">
          <b><?php echo $_SESSION['deleteBook']; unset($_SESSION['deleteBook']); ?></b>
          </p>
           <?php } ?>


           <?php
           if(isset($_SESSION['userError'])){ ?>
          <p class="alert alert-danger">
          <b><?php echo $_SESSION['userError']; unset($_SESSION['userError']); ?></b>
          </p>
           <?php } ?>

            <table class="table table-bordered table-hover" id="myTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>UserName</th>
                        <th>PassWord</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
<?php
require('connection.php');
$sql = mysqli_query($conn,'SELECT * FROM users');
while($row = mysqli_fetch_assoc($sql)){
 ?>
  <tr>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['password']; ?></td>
    <td style="width: 160px;"><button class="btn btn-sm btn-info" data-toggle="modal" data-target="#myModal<?php echo $row['id']; ?>">edit</button> 
   | <a href="deleteUser.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger">delete</a></td>
  </tr>
    <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $row['id']; ?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit User Details</h4>
        </div>
        <div class="modal-body">
        
        <form action="editUser.php?id=<?php echo $row['id']; ?>" method="POST">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="name" placeholder="Enter User Full Name" value="<?php echo $row['name']; ?>" required class="form-control">
        </div>
        <div class="form-group">
          <label>UserName</label>
          <input type="text" name="username" placeholder="Enter UserName" value="<?php echo $row['username']; ?>" required class="form-control">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="text" name="password1" placeholder="Enter PassWord" value="<?php echo $row['password']; ?>" required class="form-control">
        </div>
        <div class="form-group">
          <label>Confirm Password</label>
          <input type="text" name="password2" placeholder="Confirm PassWord" value="<?php echo $row['password']; ?>" required class="form-control">
        </div>
        

        </div>
        <div class="modal-footer">
          <button type="submit" name="btn_edit" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
</div>
<?php } ?>
                </tbody>
            </table>



    <!-- Modal -->
  <div class="modal fade" id="myuserModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add User</h4>
        </div>
        <div class="modal-body">
        
        <form action="saveuser.php" method="POST">
        <div class="form-group">
          <input type="text" name="name" placeholder="Enter User Full Name" required class="form-control">
        </div>
        <div class="form-group">
          <input type="text" name="username" placeholder="Enter UserName" required class="form-control">
        </div>
        <div class="form-group">
          <input type="text" name="password1" placeholder="Enter PassWord" required class="form-control">
        </div>
        <div class="form-group">
          <input type="text" name="password2" placeholder="Confirm PassWord" required class="form-control">
        </div>
        

        </div>
        <div class="modal-footer">
          <button type="submit" name="btn_save" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
</div>


        </div>
      </div>
   </div>
    <!-- /.container -->

<script type="text/javascript">
$('#myTable').DataTable({
  responsive: true
});

</script>
  </body>
</html>
<?php } else{
    include('login.php');
}
?>
