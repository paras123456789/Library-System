<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ps Notes</title>

    <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
  <link rel="stylesheet" href="./vendor/bootstrap.min.css">
  <script src="./vendor/jquery.min.js"></script>
  <script src="./vendor/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

  <style type="text/css">
    body{
      background-image: url('back2.png');
      background-size: cover;
    }
  </style>

  </head>

  <body>

    <!-- Page Content -->
    <div class="container">
      <br><br><br>
    <div class="row">
      <h1 style="font-size: 50px; color: grey;">Library Management System</h1>
      <div class="col-md-4 col-md-offset-4">

        <div class="panel panel-primary" style="border-radius: 0px;">
  				<div class="panel-heading"><h4>Sign In to Admin Panel</h4></div>
  				<div class="panel-body">

  					<div class="form-group">
              <label><i class="fas fa-user"></i> User ID</label>
  						<input type="text" id="username" placeholder="Enter UserName" class="form-control">
  					</div>
  					<div class="form-group">
              <label><i class="fas fa-key"></i> Password</label>
  						<input type="password" id="password" placeholder="Enter PassWord" class="form-control">
  					</div>
  					<div class="form-group">
  						<button class="btn btn-primary form-control" id="btn_login" style="border-radius: 0px;">Log In</button>
  					</div>

  				</div>
  			</div>
      </div>
    </div>
    </div>
    <!-- /.container -->

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
    	$(document).ready(function(){
    		$('#btn_login').click(function(){
    			var username = $('#username').val();
    			var password = $('#password').val();

    			if (username == "" && password == "") {
    				alert('Please Enter UserName and PassWord !')
    			}else if(username == "")
    			{
    				alert('Please Enter UserName')
    			}else if(password == "")
    			{
    				alert('Please Enter PassWord')
    			}else
    			{
    				$.ajax({
    					type:'POST',
    					url:'login_script.php',
    					data:{'username':username,'password':password},
    					success:function(data){
    						if (data == "success") {
    							window.location.href="dashboard.php";
    						}
    						if(data == "fail")
    						{
    							alert('Login Fail ! \n Invalid UserName or PassWord');
    						}
    					}
    				})
    			}
    		})
    	})
    </script>

  </body>

</html>
