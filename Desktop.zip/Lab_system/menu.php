 <nav class="navbar navbar-inverse" style="border-radius: 0px;">
  <div class="container-fluid">
    <div class="navbar-header" >
      <a class="navbar-brand" href="#">
        welcome admin
        <!-- <img src="back1.png" height="30" width="100"> -->
      </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="dashboard.php">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fas fa-book"></i> Manage Books
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="addbooks.php"><i class="fas fa-book"></i> Add Books</a></li>
          <li><a href="viewBooks.php"><i class="fas fa-book"></i> View Books</a></li>
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fas fa-book-reader"></i> Issue Books
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="issueBooks.php"><i class="fas fa-book-reader"></i> Issue Books</li>
          <li><a href="viewIssueBoooks.php"><i class="fas fa-book-reader"></i> View Issued</a></li>
        </ul>
      </li>
      <li><a href="ViewUsers.php"><i class="fas fa-users-cog"></i> Manage Users</a></li>
      <li><a href="#about" data-toggle="modal" data-target="#about"><i class="far fa-address-card"></i> About</a></li>
    </ul>
        <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sign Out</a></li>
    </ul>
  </div>
</nav> 


    <!-- Modal -->
  <div class="modal fade" id="about" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">About Us</h4>
        </div>
        <div class="modal-body">
        
        <form action="saveuser.php" method="POST">
        
        <label>Title : <span style="color: green;">Online Library Management System</span></label><br>
        <label>Created by : <span style="color: green;">Rupali Pardeshi</span></label><br>
        <label>Guided by : <span style="color: green;">xxxxxxxxxx</span></label>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
</div>