<?php
if (!isset($_SESSION)) {
session_start();
}
if(isset($_SESSION['user'])){
 ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ps Notes</title>

    <!-- Bootstrap core CSS,JS -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
  <link rel="stylesheet" href="./vendor/bootstrap.min.css">
  <script src="./vendor/jquery.min.js"></script>
  <script src="./vendor/bootstrap.min.js"></script>

  </head>

  <body>
<!-- menu bar template -->
  <?php include('menu.php'); ?>




    <!-- Page Content -->
    <div class="container">
      <br>
      <h2>Add new<span style="color: red;"> Books..</span></h2>
      <hr>
      <div class="row">
        <!-- content goes here -->
        <div class="col-md-4">
          <img src="addbook.png" height="250" width="250">
        </div>
        <div class="col-md-8">


          <?php
           if(isset($_SESSION['saveBook'])){ ?>
          <p class="alert alert-success">
          <b><?php echo $_SESSION['saveBook']; unset($_SESSION['saveBook']); ?></b>
          </p>
           <?php } ?>


          <form action="saveBook.php" method="POST">
          <div class="form-group">
            <label>Enter Book ID:</label>
            <input type="text" name="bookId" placeholder="Enter Book ID" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Enter Book Name:</label>
            <input type="text" name="bookName" placeholder="Enter Book Name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Enter Book Author:</label>
            <input type="text" name="author" placeholder="Enter Book Author" class="form-control" required>
          </div>
          <div class="form-group">
            <input type="submit" name="btn_save" value="Save" class="btn btn-success">
            <input type="reset" name="" value="Cancel" class="btn btn-danger">
          </div>
          </form>

        </div>
      </div>
   </div>
    <!-- /.container -->

    <!-- Bootstrap core JavaScript -->

  </body>
</html>
<?php } else{
    include('login.php');
}
?>
