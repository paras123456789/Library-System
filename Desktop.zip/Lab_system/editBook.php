<?php 
session_start();
require('connection.php');

if(isset($_POST['btn_edit'])){

 $id = $_GET['id'];
 $bookId = $_POST['bookId'];
 $bookName = $_POST['bookName'];
 $author = $_POST['author'];

$query = mysqli_query($conn,"UPDATE books  SET book_id='$bookId' , book_name='$bookName' , author='$author'  WHERE id = '$id' ");
if ($query) {
	$_SESSION['saveBook'] = "Book Record Updated !!";
	header('Location:viewBooks.php');
}

}

 ?>