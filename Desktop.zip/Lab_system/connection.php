<?php
$conn = mysqli_connect('localhost','root','','library') or die;
// $conn = mysqli_connect('sql207.epizy.com','epiz_22474941','oNYgi9n1L8g6pa','epiz_22474941_Test') or die;
?>
