<?php 

session_start();
require('connection.php');

 $id = $_GET['id'];

$query = mysqli_query($conn,"DELETE FROM issue_books WHERE id = '$id' ");
if ($query) {
	$_SESSION['deleteBook'] = "Record Deleted !!";
	header('Location:viewIssueBoooks.php');
}


 ?>