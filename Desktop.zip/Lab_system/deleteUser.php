<?php 

session_start();
require('connection.php');

 $id = $_GET['id'];

$query = mysqli_query($conn,"DELETE FROM users WHERE id = '$id' ");
if ($query) {
	$_SESSION['userError'] = "User Info Deleted !!";
	header('Location:ViewUsers.php');
}


 ?>