<?php 
session_start();
require('connection.php');

if(isset($_POST['btn_save'])){

 $bookId = $_POST['bookId'];
 $bookName = $_POST['bookName'];
 $author = $_POST['author'];

$query = mysqli_query($conn,"INSERT INTO books(book_id,book_name,author) VALUES('$bookId','$bookName','$author')");
if ($query) {
	$_SESSION['saveBook'] = "Book Record Saved !!";
	header('Location:addbooks.php');
}

}

 ?>