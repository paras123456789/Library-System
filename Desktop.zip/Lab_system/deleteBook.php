<?php 

session_start();
require('connection.php');

 $id = $_GET['id'];

$query = mysqli_query($conn,"DELETE FROM books WHERE id = '$id' ");
if ($query) {
	$_SESSION['deleteBook'] = "Book Record Deleted !!";
	header('Location:viewBooks.php');
}


 ?>