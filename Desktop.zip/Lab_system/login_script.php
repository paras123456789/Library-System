<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
session_start();
require('connection.php');

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query($conn,"SELECT * FROM users WHERE username = '$username' AND password = '$password' ");

if ($username == "paras" && $password == "admin@123") {
	$_SESSION['user']="owner";
	echo "success";
}else if(mysqli_num_rows($query) > 0){

		$_SESSION['user']="owner";
		echo "success";

}else{
	echo "fail";
}


}else{
	include('login.php');
}

 ?>
