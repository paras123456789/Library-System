<?php 
session_start();
require('connection.php');

if(isset($_POST['btn_edit'])){

 $id = $_GET['id'];
 $name = $_POST['name'];
 $username = $_POST['username'];
 $password1 = $_POST['password1'];
 $password2 = $_POST['password2'];

if($password1 == $password2){
$query = mysqli_query($conn,"UPDATE users SET name = '$name' , username = '$username' , password = '$password1' WHERE id = '$id' ");
if ($query) {
	$_SESSION['saveBook'] = "User Info Updated !!";
	header('Location:ViewUsers.php');
}	
}else{
    $_SESSION['userError'] = "Please enter the same password !!";
	header('Location:ViewUsers.php');
}

}

 ?>