<?php 

session_start();
require('connection.php');

if(isset($_POST['btn_edit'])){

 $id = $_GET['id'];
 $rollNo = $_POST['rollNo'];
 $bookId = $_POST['bookId'];
 $name = $_POST['name'];
 $dept = $_POST['dept'];
 $date = $_POST['date'];

$query = mysqli_query($conn,"UPDATE issue_books  SET roll_no='$rollNo' , name='$name' , dept='$dept' , book_id='$bookId' , issue_date='$date' WHERE id = '$id' ");
if ($query) {
	$_SESSION['saveBook'] = "Record Updated !!";
	header('Location:viewIssueBoooks.php');
}

}

 ?>