<?php 
session_start();
require('connection.php');

if(isset($_POST['btn_save'])){

 $name = $_POST['name'];
 $username = $_POST['username'];
 $password1 = $_POST['password1'];
 $password2 = $_POST['password2'];

if($password1 == $password2){
$query = mysqli_query($conn,"INSERT INTO users(name,username,password) VALUES('$name','$username','$password1')");
if ($query) {
	$_SESSION['saveBook'] = "User Info Saved !!";
	header('Location:ViewUsers.php');
}	
}else{
    $_SESSION['userError'] = "Please enter the same password !!";
	header('Location:ViewUsers.php');
}



}

 ?>