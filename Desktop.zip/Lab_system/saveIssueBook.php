<?php 

session_start();
require('connection.php');

if(isset($_POST['btn_save'])){

 $bookId = $_POST['bookId'];
 $name = $_POST['name'];
 $rollNo = $_POST['rollNo'];
 $dept = $_POST['dept'];
 $date = $_POST['date'];

$query = mysqli_query($conn,"INSERT INTO issue_books(roll_no,name,dept,book_id,issue_date) VALUES('$rollNo','$name','$dept','$bookId','$date')");
if ($query) {
	$_SESSION['saveBook'] = "Book Issued Successfully !!";
	header('Location:issueBooks.php');
}

}

 ?>