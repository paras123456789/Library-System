<?php
if (!isset($_SESSION)) {
session_start();
}
if(isset($_SESSION['user'])){
 ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ps Notes</title>

    <!-- Bootstrap core CSS,JS -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
  <link rel="stylesheet" href="./vendor/bootstrap.min.css">
  <!-- <link rel="stylesheet" type="text/css" href="./jquery.dataTables.min.css"> -->
  <script src="./vendor/jquery.min.js"></script>
  <script src="./vendor/bootstrap.min.js"></script>


  </head>

  <body>
<!-- menu bar template -->
  <?php include('menu.php'); ?>



    <!-- Page Content -->
    <div class="container">
      <br>
      <h2>Welcome to <span style="color: red;"> Library Management System</span></h2>
      <hr>
      <div class="row">
        <!-- content goes here -->
      </div>
   </div>
    <!-- /.container -->

    <!-- Bootstrap core JavaScript -->
  <!--   <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="vendor/jquery.dataTables.min.js"></script> -->
<script type="text/javascript">
// $('#myTable').DataTable({
//   responsive: true
// });

// $('#saveForm').submit(function(e){
//   alert('called')
//   e.preventDefault();
// })

</script>
  </body>
</html>
<?php } else{
    include('login.php');
}
?>
